package problemstatement3_1;

public class Guitar extends Instrument {

	@Override
	public void play() {
		System.out.println("Guitar is playing  tin  tin  tin");

	}

}