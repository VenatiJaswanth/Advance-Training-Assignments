package com.springboot;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class ProductDAOImpl implements ProductDAO  {
	
	
	@Autowired
	private SessionFactory sessionFactory;

	
	@Override
	@Transactional
	public void addProduct(Product product) {
		
		// get current hibernate session
				Session currentSession = sessionFactory.getCurrentSession();

				// save/update
				currentSession.saveOrUpdate(product);

	}
}

