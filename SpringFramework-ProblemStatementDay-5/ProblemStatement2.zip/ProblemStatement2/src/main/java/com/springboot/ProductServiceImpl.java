package com.springboot;

import java.util.List;

public class ProductServiceImpl implements ProductService {

	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void FindByProductId(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteByProductId(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateByProductId(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Product> allProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void FindByCategory(String name) {
		// TODO Auto-generated method stub
		
	}



}

