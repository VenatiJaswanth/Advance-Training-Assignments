package com.springboot.entity;

public class Product {

}
