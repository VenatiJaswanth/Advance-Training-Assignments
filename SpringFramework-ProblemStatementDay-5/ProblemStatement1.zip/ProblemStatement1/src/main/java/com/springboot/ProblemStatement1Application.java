package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProblemStatement1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProblemStatement1Application.class, args);
	}

}
