package com.springboot.repository;

public class ProductRepository {

}
