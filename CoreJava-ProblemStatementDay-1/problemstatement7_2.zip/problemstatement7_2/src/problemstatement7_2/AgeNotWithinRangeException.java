package problemstatement7_2;

public class AgeNotWithinRangeException extends Exception{


    public String toString()
    {
         return ("Age is not between 14 and 18. please ReEnter the Age");
    }
}
